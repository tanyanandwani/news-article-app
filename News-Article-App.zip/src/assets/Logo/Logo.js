import React from 'react';
import Logo from './logo.png';
import './Logo.css';

const logo=()=>(<img src={Logo} alt='News App Logo'/>);

export default logo;