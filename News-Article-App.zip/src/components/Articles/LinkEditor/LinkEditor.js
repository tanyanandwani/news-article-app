import React from 'react';

const linkEditor=(props)=>{
    return(
        <div className='container LinkEditor'>
        
        </div>
    );
}

export default linkEditor;